<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WpTerm extends Model
{
    //
}
