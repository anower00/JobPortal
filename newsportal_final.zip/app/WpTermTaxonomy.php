<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WpTermTaxonomy extends Model
{
    //
}
