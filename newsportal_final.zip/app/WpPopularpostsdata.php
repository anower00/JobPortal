<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WpPopularpostsdata extends Model
{
    //
}
