<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WpUser extends Model
{
    //
}
