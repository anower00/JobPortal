@extends('layouts.admin')
@section('page_title')
Admin Dashboard    
@endsection
@section('body_content')
No Access
@endsection